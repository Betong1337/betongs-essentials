package me.betong.essentials;

/**
 * Unit test for simple App.
 */
public class AppTest 
{

    public void shouldAnswerWithTrue()
    {

    }
}
